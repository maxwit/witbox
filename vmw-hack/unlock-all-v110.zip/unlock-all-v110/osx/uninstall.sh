#!/bin/sh
set -e

echo VMware Unlocker 1.1.0
echo =====================
echo Copyright: Dave Parsons 2012

# Ensure we only use unmodified commands
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

echo Patching...
./Unlocker.OSX -u

echo Finished!

