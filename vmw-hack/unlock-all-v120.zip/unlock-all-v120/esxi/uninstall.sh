#!/bin/sh
set -e

echo VMware ESXi 5.x Unlocker 1.2.0
echo ===============================
echo Copyright: Dave Parsons 2011-13

# Ensure we only use unmodified commands
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

# Remove entry from the boot configuration file
echo Deleting darwin.tgz from boot.cfg...
BootModuleConfig.sh --remove=darwin.vgz --verbose

echo Please now reboot the host system!
